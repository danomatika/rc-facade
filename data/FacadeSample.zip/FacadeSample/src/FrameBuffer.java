
import java.awt.Color;
import java.net.*;

/**
 * implements the interface to the facade simulator
 */
public class FrameBuffer {

	private final int packageSize = 5;		///< size of a package (address+color)
	private final int nrAddresses = 1085;   ///< total number of packages;
	private final int offsetRed = 2;		///< offset of red color in package
	private final int offsetGreen = 3;		///< offset of green color in package
	private final int offsetBlue = 4;		///< offset of blue color in package
	private byte[] frameBuffer = new byte[packageSize*nrAddresses];
	
	public FrameBuffer() {
		for (int address = 0; address < nrAddresses; address++) {
			frameBuffer[address*packageSize + 0] = (byte) (address % 256);
			frameBuffer[address*packageSize + 1] = (byte) (address / 256);
			frameBuffer[address*packageSize + offsetRed] = 0;
			frameBuffer[address*packageSize + offsetGreen] = 0;
			frameBuffer[address*packageSize + offsetBlue] = 0;
		}
	}

	/**
	 * set all packages to the same color
	 */
	public void setColor(Color color) {
		for (int address = 0; address < nrAddresses; address++) {
			frameBuffer[address*packageSize + offsetRed] = (byte) color.getRed();
			frameBuffer[address*packageSize + offsetGreen] = (byte) color.getGreen();
			frameBuffer[address*packageSize + offsetBlue] = (byte) color.getBlue();			
		}
	}
	
	/**
	 * set package at address to color
	 */
	public void setColor(int address, Color color) {
		if (address >= 0 && address < nrAddresses) {
			frameBuffer[address*packageSize + offsetRed] = (byte) color.getRed();
			frameBuffer[address*packageSize + offsetGreen] = (byte) color.getGreen();
			frameBuffer[address*packageSize + offsetBlue] = (byte) color.getBlue();						
		}
	}
	
	/**
	 * send the complete UDP packet to localhost:8080 (might be necessary to change)
	 */
	public void flush() {
		try {
			DatagramPacket packet = new DatagramPacket(frameBuffer, frameBuffer.length, InetAddress.getLocalHost(), 8080);
			DatagramSocket socket = new DatagramSocket();
			socket.send(packet);
		}
		catch (Exception e) {
			System.out.println("Exception when sending framebuffer: " + e.getMessage());
		}
	}
}
