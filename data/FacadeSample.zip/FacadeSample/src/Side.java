
import java.awt.Color;

/**
 * abstract base class for building sides, initialized in derived
 * classes to represent a certain side.
 */
public abstract class Side {

	protected String name;
	protected int startAddr;		///< first window address
	protected int endAddr;			///< last window address
	protected int startRow;			///< index of top row in an overall numbering
	protected int endRow;			///< index of last row in an overall numbering
	protected int nrColumns;		///< number of columns
	protected int[][] windowAddrs;	///< window addresses of this side
	
	public String getName() {
		return name;
	}
	public int getStartAddress() {
		return startAddr;
	}
	public int getEndAddress() {
		return endAddr;
	}
	public int getStartRow() {
		return startRow;
	}
	public int getEndRow() {
		return endRow;
	}
	public int getNrColumns() {
		return nrColumns;
	}
	
	/**
	 * retrieve the address of the window at a certain position
	 * @param row		index of row
	 * @param column	index of column
	 * @return			window address of row/column, -1 if no window at this position 
	 */
	public int getAddress(int row, int column) {
		if (row >= startRow && row <= endRow) {
			if (column >= 0 && column < nrColumns) {
				return windowAddrs[row-startRow][column];
			}
		}
		return -1;
	}
	
	/**
	 * set side to a particular color
	 */
	public void setColor(FrameBuffer frame, Color color) {
		for (int address = getStartAddress(); address <= getEndAddress(); address++) {
			frame.setColor(address, color);
		}
	}
	/**
	 * set row of side to a particular color
	 */
	public void setRowColor(FrameBuffer frame, int row, Color color) {
		if (row >= getStartRow() && row <= getEndRow()) {
			for (int column = 0; column < getNrColumns(); column++) {
				frame.setColor(getAddress(row, column), color);
			}
		}
	}
	/**
	 * set column of side to a particular color
	 */
	public void setColumnColor(FrameBuffer frame, int column, Color color) {
		if (column >= 0 && column < getNrColumns()) {
			for (int row = getStartRow(); row <= getEndRow(); row++) {
				frame.setColor(getAddress(row, column), color);
			}
		}
	}
	/**
	 * set window at row/column to particular color.
	 * do nothing, if there is no window at that position.
	 */
	public void setWindowColor(FrameBuffer frame, int row, int column, Color color) {
		frame.setColor(getAddress(row, column), color);
	}
}
