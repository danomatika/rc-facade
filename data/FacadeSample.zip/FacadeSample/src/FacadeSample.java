
import java.util.*;
import java.awt.Color;

/**
 * sample for an application with the facade simulator
 */
public class FacadeSample {

	private static List<Color> colors = new ArrayList<Color>();
	private static Color background = new Color(1,1,1);
	private static FrameBuffer frame = new FrameBuffer();
	private static Building building = new Building();

	/**
	 * display the whole building in a various colors
	 */
	private static void walkColors() {
		for (Color color: colors) {
			System.out.println("Set building to " + color.toString());
			frame.setColor(color);
			frame.flush();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
			}
		}
		frame.setColor(background);
	}
	/**
	 * walk through the sides of the building and display various colors
	 */
	private static void walkSides() {
		for (Side side: building.getSides()) {
			frame.setColor(background);
			for (Color color: colors) {
				System.out.println("Set " + side.getName() + " to " + color.toString());
				side.setColor(frame, color);
				frame.flush();
				try {
					Thread.sleep(400);
				} catch (InterruptedException e) {
				}
			}
		}
	}
	/**
	 * walk through the window rows of the whole building 
	 */
	private static void walkRows() {
		for (Color color: colors) {
			for (int row = 0; row < building.getNrRows(); row++) {
				System.out.println("Set row " + row + " to " + color.toString());
				frame.setColor(background);
				for (Side side: building.getSides()) {
					side.setRowColor(frame, row, color);
				}
				frame.flush();
				try {
					Thread.sleep(400);
				} catch (InterruptedException e) {
				}
			}
		}
	}
	/**
	 * walk through the window columns of the whole building
	 */
	private static void walkColumns() {
		for (Color color: colors) {
			for (int column = 0; column < building.getNrColumns(); column++) {
				System.out.println("Set column " + column + " to " + color.toString());
				frame.setColor(background);
				for (Side side: building.getSides()) {
					side.setColumnColor(frame, column, color);
				}
				frame.flush();
				try {
					Thread.sleep(400);
				} catch (InterruptedException e) {
				}
			}
		}
	}
	
	public static void main(String[] args) {
		System.out.println("Facade Sample");

		colors.add(Color.red);
		colors.add(Color.green);
		colors.add(Color.blue);
		colors.add(Color.yellow);
		colors.add(Color.magenta);
		colors.add(Color.cyan);
		colors.add(new Color(254,254,254));
		
		walkColors();
		walkSides();
		walkRows();
		walkColumns();
	}

}
