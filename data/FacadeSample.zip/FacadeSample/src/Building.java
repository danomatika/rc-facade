
import java.util.*;

/**
 * represents the building as a list of bulding sides
 */
public class Building {
	
	private List<Side> sides = new ArrayList<Side>();
	private int nrRows = 0;		///< the overall number of rows of the building
	private int nrColumns = 0;	///< the maximum number of columns of a side

	public Building() {
		sides.add(new SideMainBuildingNorth());
		sides.add(new SideMainBuildingEast());
		sides.add(new SideMainBuildingSouth());
		sides.add(new SideMainBuildingSouthStreetLevel());
		sides.add(new SideMainBuildingWest());
		sides.add(new SideFuturelabNorth());
		sides.add(new SideFuturelabEast());
		sides.add(new SideFuturelabSouth());
		
		for (Side side: sides) {
			if (side.getEndRow()+1 > nrRows) {
				nrRows = side.getEndRow()+1;
			}
			if (side.getNrColumns() > nrColumns) {
				nrColumns = side.getNrColumns();
			}
		}
	}
	
	public List<Side> getSides() {
		return sides;
	}
	public int getNrRows() {
		return nrRows;
	}
	public int getNrColumns() {
		return nrColumns;
	}
}
